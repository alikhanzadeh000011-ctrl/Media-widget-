package com.example.mediawidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.RemoteViews
import java.util.concurrent.Executors

object MediaWidgetUpdater {

    private val executor = Executors.newSingleThreadExecutor()

    // کش: تا وقتی آهنگ و سایز عوض نشده بلر دوباره ساخته نشه
    private var cacheKey: String? = null
    private var cachedBg: Bitmap? = null
    private var cachedCover: Bitmap? = null

    private data class Info(
        val hasAccess: Boolean = true,
        val title: String = "",
        val artist: String = "",
        val art: Bitmap? = null,
        val playing: Boolean = false,
        val open: PendingIntent? = null
    ) {
        val key get() = "$title|$artist|${art?.width}"
    }

    fun update(context: Context) {
        val app = context.applicationContext
        executor.execute {
            try { render(app) } catch (e: Exception) { e.printStackTrace() }
        }
    }

    fun pickController(sessions: List<MediaController>): MediaController? =
        sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: sessions.firstOrNull { it.metadata != null }

    private fun render(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, MediaWidgetProvider::class.java))
        if (ids.isEmpty()) return
        val info = currentInfo(ctx)
        for (id in ids) mgr.updateAppWidget(id, build(ctx, mgr, id, info))
    }

    private fun currentInfo(ctx: Context): Info {
        val msm = ctx.getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(ctx, MediaListenerService::class.java)
        val sessions = try {
            msm.getActiveSessions(cn)
        } catch (e: SecurityException) {
            return Info(hasAccess = false)
        }
        val c = pickController(sessions) ?: return Info()
        val md = c.metadata
        val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: loadUri(ctx, md?.getString(MediaMetadata.METADATA_KEY_ART_URI))
            ?: loadUri(ctx, md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI))
        return Info(
            title = md?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty(),
            artist = (md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty(),
            art = art,
            playing = c.playbackState?.state == PlaybackState.STATE_PLAYING,
            open = c.sessionActivity
        )
    }

    private fun loadUri(ctx: Context, uri: String?): Bitmap? {
        if (uri.isNullOrEmpty()) return null
        val u = Uri.parse(uri)
        if (u.scheme != "content" && u.scheme != "file") return null
        return try {
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) { null }
    }

    // ---------------------------------------------------------------- views

    private fun build(ctx: Context, mgr: AppWidgetManager, id: Int, info: Info): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_media)
        val d = ctx.resources.displayMetrics.density

        val opts = mgr.getAppWidgetOptions(id)
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 110).coerceAtLeast(110)
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 110).coerceAtLeast(110)
        val w = wDp * d
        val h = hDp * d
        val s = minOf(1f, 400f / maxOf(w, h)) // سایز بیتمپ رو برای محدودیت Binder کوچیک نگه می‌داریم
        val bw = (w * s).toInt()
        val bh = (h * s).toInt()

        val art = info.art
        if (art != null) {
            val key = "${info.key}|$bw|$bh"
            if (key != cacheKey) {
                val safe = art.copy(Bitmap.Config.ARGB_8888, false)
                cachedBg = makeBackground(safe, bw, bh, 24 * d * s)
                cachedCover = makeCover(safe, (56 * d).toInt().coerceIn(96, 256), 12 * d)
                cacheKey = key
            }
            rv.setImageViewBitmap(R.id.bg, cachedBg)
            rv.setImageViewBitmap(R.id.cover, cachedCover)
        } else {
            cacheKey = null
            rv.setImageViewResource(R.id.bg, R.drawable.widget_bg_default)
            rv.setImageViewResource(R.id.cover, R.drawable.cover_placeholder)
        }

        rv.setTextViewText(R.id.title, when {
            !info.hasAccess -> "Tap to allow access"
            info.title.isEmpty() -> "Not playing"
            else -> info.title
        })
        rv.setTextViewText(R.id.artist, info.artist)
        rv.setImageViewResource(R.id.btn_icon, if (info.playing) R.drawable.ic_pause else R.drawable.ic_play)
        rv.setTextViewText(R.id.btn_text, if (info.playing) "Pause" else "Play")

        // کلیک‌ها
        val openApp = if (!info.hasAccess) {
            activity(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), 1)
        } else info.open ?: activity(
            ctx,
            ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: Intent(Settings.ACTION_SOUND_SETTINGS),
            2
        )
        rv.setOnClickPendingIntent(R.id.cover, openApp)
        rv.setOnClickPendingIntent(R.id.title, openApp)
        rv.setOnClickPendingIntent(R.id.artist, openApp)

        val toggle = PendingIntent.getBroadcast(
            ctx, 3,
            Intent(ctx, MediaWidgetProvider::class.java).setAction(MediaWidgetProvider.ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        rv.setOnClickPendingIntent(R.id.btn_play, toggle)

        val outputIntent = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_VOLUME)
        else Intent(Settings.ACTION_SOUND_SETTINGS)
        rv.setOnClickPendingIntent(R.id.cast, activity(ctx, outputIntent, 4))
        rv.setOnClickPendingIntent(R.id.output, activity(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS), 5))
        return rv
    }

    private fun activity(ctx: Context, intent: Intent, code: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, code, intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    // --------------------------------------------------------------- bitmaps

    /** کاور → center-crop → کوچیک‌سازی → باکس‌بلر → بزرگ‌سازی → گوشه‌گرد */
    private fun makeBackground(src: Bitmap, w: Int, h: Int, radius: Float): Bitmap {
        val cropped = centerCrop(src, w, h)
        val smallW = 40
        val smallH = (smallW * h / w.toFloat()).toInt().coerceAtLeast(8)
        val small = Bitmap.createScaledBitmap(cropped, smallW, smallH, true)
        val blurred = boxBlur(small, 3, 3)
        val big = Bitmap.createScaledBitmap(blurred, w, h, true)
        return rounded(big, radius)
    }

    private fun makeCover(src: Bitmap, size: Int, radius: Float): Bitmap {
        val sq = centerCrop(src, 1, 1)
        return rounded(Bitmap.createScaledBitmap(sq, size, size, true), radius)
    }

    private fun centerCrop(src: Bitmap, w: Int, h: Int): Bitmap {
        val target = w.toFloat() / h
        val cur = src.width.toFloat() / src.height
        return if (cur > target) {
            val nw = (src.height * target).toInt()
            Bitmap.createBitmap(src, (src.width - nw) / 2, 0, nw, src.height)
        } else {
            val nh = (src.width / target).toInt()
            Bitmap.createBitmap(src, 0, (src.height - nh) / 2, src.width, nh)
        }
    }

    private fun rounded(src: Bitmap, radius: Float): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawRoundRect(RectF(0f, 0f, src.width.toFloat(), src.height.toFloat()), radius, radius, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(src, 0f, 0f, p)
        return out
    }

    private fun boxBlur(bmp: Bitmap, r: Int, passes: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        var a = IntArray(w * h)
        var b = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        repeat(passes) {
            blurPass(a, b, w, h, r, true)
            blurPass(b, a, w, h, r, false)
        }
        return Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val n = 2 * r + 1
        for (y in 0 until h) for (x in 0 until w) {
            var sr = 0; var sg = 0; var sb = 0
            for (k in -r..r) {
                val xx = if (horizontal) (x + k).coerceIn(0, w - 1) else x
                val yy = if (horizontal) y else (y + k).coerceIn(0, h - 1)
                val c = src[yy * w + xx]
                sr += (c shr 16) and 0xFF
                sg += (c shr 8) and 0xFF
                sb += c and 0xFF
            }
            dst[y * w + x] = (0xFF shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
        }
    }
}
