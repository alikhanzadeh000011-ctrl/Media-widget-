package com.example.mediawidget

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val text = TextView(this).apply {
            text = "۱) دسترسی Notification access رو برای Media Widget روشن کن.\n" +
                "۲) بعد روی هوم‌اسکرین: نگه داشتن → Widgets → Media Widget."
            textSize = 16f
            setPadding(0, 0, 0, pad)
        }
        val button = Button(this).apply {
            text = "باز کردن تنظیمات دسترسی"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(text)
            addView(button)
        })
    }
}
