package com.example.mediawidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle

class MediaWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        MediaWidgetUpdater.update(context)
    }

    override fun onAppWidgetOptionsChanged(context: Context, mgr: AppWidgetManager, id: Int, opts: Bundle) {
        MediaWidgetUpdater.update(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            try {
                val msm = context.getSystemService(MediaSessionManager::class.java)
                val sessions = msm.getActiveSessions(ComponentName(context, MediaListenerService::class.java))
                val c = MediaWidgetUpdater.pickController(sessions) ?: return
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                else c.transportControls.play()
            } catch (_: SecurityException) {
                // دسترسی Notification Access داده نشده
            }
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.example.mediawidget.ACTION_TOGGLE"
    }
}
